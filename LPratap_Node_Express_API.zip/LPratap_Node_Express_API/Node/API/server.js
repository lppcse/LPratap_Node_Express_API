var express = require('express');
var app = express();

const data = require('./data.json')


app.get('/', function(request, response) {
    response.header("Access-Control-Allow-Origin", "*");
    response.send(data);
});

var port = 5000;

app.listen(port, function() {
    console.log('Server listening: http://localhost:' + port);
}); 