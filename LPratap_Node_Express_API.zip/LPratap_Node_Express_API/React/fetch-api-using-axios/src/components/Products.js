import Service from './Axios/Service';

const ProductsFetch = async () => {
    const data = await Service('http://localhost:5000/');
    //console.log(data);

    // display product list and add routing for navigation ahead 
}

const Products = () => {
    ProductsFetch('http://localhost:5000/');
    
}

export default Products;