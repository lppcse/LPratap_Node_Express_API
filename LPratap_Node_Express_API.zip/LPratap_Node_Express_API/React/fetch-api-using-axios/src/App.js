import logo from './logo.svg';
import './App.css';
import Products from './components/Products';

function App() {
  return (
    <div className="App">
      <header className="App-header">
       Product List
      </header>
      <Products />
    </div>
  );
}

export default App;
